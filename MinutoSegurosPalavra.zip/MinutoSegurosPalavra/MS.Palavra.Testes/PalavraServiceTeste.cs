using Microsoft.Extensions.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using MS.Palavra.Domain.Interfaces.Service;
using MS.Palavra.Service.Services;
using System.Collections.Generic;

namespace MS.Palavra.Testes
{
    [TestClass]
    public class PalavraServiceTeste
    {
        public static IConfiguration InitConfiguration()
        {
            return new ConfigurationBuilder().Build();
        }

        [TestMethod]
        public void ValidarTratamentoPalavraOk()
        {
            #region Mock
            var mockTeste = "<title>Onde pagar o licenciamento do meu carro?</title>";
            var mockPalavraItens = new List<string>();
            mockPalavraItens.AddRange(new List<string>() { "Onde", "pagar", "licenciamento", "meu", "carro" });
            var mock = new Mock<IPalavraService>();
            mock.Setup(m => m.ObterPalavras(mockTeste)).Returns(mockPalavraItens);
            #endregion
            var palavraService = new PalavraService(InitConfiguration());
            var resultadoEsperado = mock.Object.ObterPalavras(mockTeste).Count;
            var resultado = palavraService.ObterPalavras(mockTeste).Count;
            Assert.AreEqual(resultado, resultadoEsperado);
        }

        [TestMethod]
        public void ValidarTratamentoPalavraNOk()
        {
            #region Mock
            var mockTeste = "<title>Onde pagar o licenciamento do meu carro?</title> palavra a mais";
            var mockPalavraItens = new List<string>();
            mockPalavraItens.AddRange(new List<string>() { "feed", "palavra", "conte�do", "fato", "atual", "mais" });
            var mock = new Mock<IPalavraService>();
            mock.Setup(m => m.ObterPalavras(mockTeste)).Returns(mockPalavraItens);
            #endregion
            var palavraService = new PalavraService(InitConfiguration());
            var resultadoEsperado = mock.Object.ObterPalavras(mockTeste).Count;
            var resultado = palavraService.ObterPalavras(mockTeste).Count;
            Assert.AreNotEqual(resultado, resultadoEsperado);
        }
    }
}

