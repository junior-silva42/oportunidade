﻿using Microsoft.EntityFrameworkCore;
using MS.Palavra.Domain.Entities.Base;
using System.Linq;

namespace MS.Palavra.Infra.Context
{
    public class PalavraContext : DbContext
    {

        public PalavraContext()
        {
        }

        public PalavraContext(DbContextOptions<PalavraContext> options) : base(options)
        {
        }

        //public DbSet<Palavra> Palavra { get; set; }

        public void DetachLocal<T>(T t, int entryId) where T : BaseEntity
        {
            var local = this.Set<T>().Local.FirstOrDefault(entry => entry.Id == entryId);

            if (local != null)
            {
                this.Entry(local).State = EntityState.Detached;
            }
            this.Entry(t).State = EntityState.Modified;
        }
    }
}