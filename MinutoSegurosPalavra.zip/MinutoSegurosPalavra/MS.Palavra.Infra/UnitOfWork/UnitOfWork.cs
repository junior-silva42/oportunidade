﻿using Microsoft.EntityFrameworkCore.Storage;
using MS.Palavra.Domain.Interfaces.UnitOfWork;
using MS.Palavra.Infra.Context;

namespace MS.Palavra.Infra.UnitOfWork
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly PalavraContext _context;

        public UnitOfWork(PalavraContext context)
        {
            _context = context;
        }

        public IDbContextTransaction BeginTransaction()
        {
            return _context.Database.BeginTransaction();
        }

        public void Commit()
        {
            _context.SaveChanges();
        }
    }
}