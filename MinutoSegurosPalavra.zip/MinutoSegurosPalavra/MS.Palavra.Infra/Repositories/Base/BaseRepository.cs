﻿using Microsoft.EntityFrameworkCore;
using MS.Palavra.Domain.Entities.Base;
using MS.Palavra.Domain.Interfaces.Repository;
using MS.Palavra.Infra.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace MS.Palavra.Infra.Repositories.Base
{
    public class BaseRepository<TEntity> : IRepository<TEntity> where TEntity : BaseEntity
    {
        protected PalavraContext _context;
        protected DbSet<TEntity> dbSet;

        public BaseRepository(PalavraContext context)
        {
            _context = context;
            dbSet = _context.Set<TEntity>();
        }

        #region Ações
        public virtual TEntity Incluir(TEntity obj)
        {
            return dbSet.Add(obj).Entity;
        }

        public virtual TEntity ObterPorId(int id)
        {
            return dbSet.Find(id);
        }

        public virtual IEnumerable<TEntity> ObterTodos()
        {
            return dbSet;
        }

        public virtual TEntity Alterar(TEntity obj)
        {
            _context.DetachLocal<TEntity>(obj, obj.Id);

            return obj;
        }

        public virtual void Remover(int id)
        {
            dbSet.Remove(dbSet.Find(id));
        }

        public IEnumerable<TEntity> Buscar(Expression<Func<TEntity, bool>> predicate)
        {
            return dbSet.Where(predicate);
        }
        #endregion

        #region Transações
        public int SaveChanges()
        {
            return _context.SaveChanges();
        }

        public void Dispose()
        {
            _context.Dispose();
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
