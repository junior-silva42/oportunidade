﻿using MS.Palavra.Infra.Helper;

namespace MS.Palavra.Infra.CrossCutting
{
    public  class FeedCrossCutting
    {
        public  string ObterFeed(string url)
        {
            var feed = HttpHelper.GetAsync(url).Result;
            return feed;
        }
    }
}
