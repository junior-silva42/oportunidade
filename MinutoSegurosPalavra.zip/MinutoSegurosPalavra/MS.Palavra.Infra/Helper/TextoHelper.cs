﻿using System.Linq;
using System.Text.RegularExpressions;

namespace MS.Palavra.Infra.Helper
{
    public static class TextoHelper
    {
        public static string RetornaApenasLetrasNumeros(string texto)
        {
            return new Regex(@"[^0-9a-zA-Záéíóúàèìòùâêîôûãõç ]+").Replace(texto, string.Empty);
        }

        public static string RemoveTags(string texto)
        {
            return new Regex("<.*?>").Replace(texto, string.Empty);
        }

        public static string RemoverPreposicoesEArtigos(string texto)
        {
            var preposicoesEArtigos = PreposicoesEArtigos();
            string textoRetorno = string.Empty;
            foreach (var palavra in texto.ToLower().Split(' '))
            {
                if (!string.IsNullOrEmpty(palavra) && preposicoesEArtigos.Where(x => x.Equals(palavra)).Count() == 0)
                    textoRetorno += " " + palavra;
            }
            return textoRetorno;
        }

        public static string[] PreposicoesEArtigos()
        {
            return new string[] { "e", "como","o", "os", "a", "as", "um", "uns", "uma", "umas", "ao", "aos", "à", "às", "do", "dos",
                                                     "da", "das", "dum", "duns", "duma", "dumas", "no", "nos", "na", "nas", "num", "nuns",
                                                     "numa", "numas", "pelo", "pelos", "pela", "pelas", "a", "de", "em", "por", "para" };
        }
    }
}
