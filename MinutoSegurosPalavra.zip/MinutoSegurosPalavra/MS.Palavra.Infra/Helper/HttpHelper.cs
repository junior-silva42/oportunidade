﻿using System.Net.Http;
using System.Threading.Tasks;

namespace MS.Palavra.Infra.Helper
{
    public static class HttpHelper
    {
        public static async Task<string> GetAsync(string url)
        {
            HttpClient cliente = new HttpClient();
            return await cliente.GetStringAsync(url);
        }
    }
}
