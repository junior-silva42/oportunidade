﻿namespace MS.Palavra.Domain.Arguments
{
    public class PalavraQuantidadeResponse
    {
        public string Palavra { get; set; }
        public int Quantidade { get; set; }
    }
}
