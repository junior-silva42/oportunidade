﻿namespace MS.Palavra.Domain.Arguments
{
    public class FeedResponse
    {
        public string Topico { get; set; }
        public string Conteudo { get; set; }
    }
}
