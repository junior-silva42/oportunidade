﻿namespace MS.Palavra.Domain.Arguments
{
    public class TopicoQuantidadePalavraResponse
    {
        public string Topico { get; set; }
        public int Quantidade { get; set; }
    }
}
