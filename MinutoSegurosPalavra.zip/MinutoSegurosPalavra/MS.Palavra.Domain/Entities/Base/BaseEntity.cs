﻿namespace MS.Palavra.Domain.Entities.Base
{
    public abstract class BaseEntity
    {
        public virtual int Id { get; set; }
    }
}
