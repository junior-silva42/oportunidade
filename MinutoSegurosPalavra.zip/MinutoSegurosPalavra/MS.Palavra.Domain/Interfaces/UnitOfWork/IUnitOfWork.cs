﻿using Microsoft.EntityFrameworkCore.Storage;

namespace MS.Palavra.Domain.Interfaces.UnitOfWork
{
    public interface IUnitOfWork
    {
        void Commit();
        IDbContextTransaction BeginTransaction();
    }
}