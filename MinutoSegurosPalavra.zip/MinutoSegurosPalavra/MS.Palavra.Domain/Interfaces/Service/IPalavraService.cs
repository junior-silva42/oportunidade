﻿using MS.Palavra.Domain.Arguments;
using System.Collections.Generic;

namespace MS.Palavra.Domain.Interfaces.Service
{
    public interface IPalavraService
    {
        IEnumerable<PalavraQuantidadeResponse> ObterQuantidadeDasPalavrasTopDez();
        IEnumerable<TopicoQuantidadePalavraResponse> ObterQuantidadePalavrasTopico();
        List<string> ObterPalavras(string conteudo);
    }
}
