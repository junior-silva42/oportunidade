﻿using Microsoft.Extensions.Configuration;
using MS.Palavra.Domain.Arguments;
using MS.Palavra.Domain.Interfaces.Service;
using MS.Palavra.Infra.CrossCutting;
using MS.Palavra.Infra.Helper;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.ServiceModel.Syndication;
using System.Xml;

namespace MS.Palavra.Service.Services
{
    public class PalavraService : IPalavraService
    {
        private readonly IConfiguration _configuration;
        public PalavraService(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        #region Pegar feed
        private IEnumerable<FeedResponse> ObterTopDezUltimosFeed()
        {
            string xml = new FeedCrossCutting().ObterFeed(_configuration.GetSection("UrlFeed").Value);
            List<FeedResponse> feeds = new List<FeedResponse>();
            using (var reader = XmlReader.Create(new StringReader(xml)))
            {
                var feedSite = SyndicationFeed.Load(reader);

                foreach (var feed in feedSite.Items.OrderByDescending(m => m.PublishDate).Take(10))
                {
                    feeds.Add(new FeedResponse()
                    { Conteudo = feed.Summary.Text, Topico = feed.Title.Text });
                }
            }
            return feeds;
        }
        #endregion

        #region Tratar Palavras
        public List<string> ObterPalavras(string conteudo)
        {
            var retorno = new List<string>();
            conteudo = TextoHelper.RemoveTags(conteudo);
            conteudo = TextoHelper.RetornaApenasLetrasNumeros(conteudo);
            conteudo = TextoHelper.RemoverPreposicoesEArtigos(conteudo);
            foreach (var palavra in conteudo.Split(" "))
            {
                if (!string.IsNullOrEmpty(palavra))
                    retorno.Add(palavra.ToLower().Trim());
            }
            return retorno;
        }
        #endregion

        #region Quantidade de palavras/topicos
        private IEnumerable<PalavraQuantidadeResponse> ObterQuantidadeDasPalavras(List<string> palavras)
        {
            var retorno = new List<PalavraQuantidadeResponse>();

            foreach (var palavraAgrupada in palavras.GroupBy(i => i))
            {
                var palavra = new PalavraQuantidadeResponse()
                {
                    Palavra = palavraAgrupada.Key,
                    Quantidade = palavraAgrupada.Count()
                };
                retorno.Add(palavra);
            }

            return retorno;
        }

        public IEnumerable<PalavraQuantidadeResponse> ObterQuantidadeDasPalavrasTopDez()
        {
            IEnumerable<FeedResponse> feeds = ObterTopDezUltimosFeed();
            List<string> palavras = new List<string>();
            foreach (var palavra in feeds)
            {
                palavras.AddRange(ObterPalavras(palavra.Conteudo));
            }
            return ObterQuantidadeDasPalavras(palavras).OrderByDescending(x => x.Quantidade).Take(10);
        }

        public IEnumerable<TopicoQuantidadePalavraResponse> ObterQuantidadePalavrasTopico()
        {
            IEnumerable<FeedResponse> feeds = ObterTopDezUltimosFeed();
            var retorno = new List<TopicoQuantidadePalavraResponse>();
            foreach (var feed in feeds)
            {
                retorno.Add(new TopicoQuantidadePalavraResponse()
                {
                    Topico = feed.Topico,
                    Quantidade = (ObterPalavras(feed.Conteudo)).Count()
                });
            }
            return retorno.OrderByDescending(x => x.Quantidade);
        }

        public IEnumerable<PalavraQuantidadeResponse> ObterQuantidadePalavrasTopico(List<string> palavras)
        {
            var retorno = new List<PalavraQuantidadeResponse>();

            foreach (var palavraAgrupada in palavras.GroupBy(i => i))
            {
                var palavra = new PalavraQuantidadeResponse()
                {
                    Palavra = palavraAgrupada.Key,
                    Quantidade = palavraAgrupada.Count()
                };

                retorno.Add(palavra);
            }

            return retorno;
        }
        #endregion
    }
}
