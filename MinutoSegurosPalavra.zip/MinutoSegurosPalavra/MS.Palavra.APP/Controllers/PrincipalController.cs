﻿using Microsoft.AspNetCore.Mvc;
using MS.Palavra.Domain.Arguments;
using MS.Palavra.Domain.Interfaces.Service;
using System.Collections.Generic;

namespace MS.Palavra.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PrincipalController : ControllerBase
    {
        private readonly IPalavraService _palavraService;

        public PrincipalController(IPalavraService palavraService)
        {
            _palavraService = palavraService;
        }
        [Route("ObterQuantidadeDasPalavrasTopDez")]
        [HttpGet]
        public ActionResult<IEnumerable<PalavraQuantidadeResponse>> ObterQuantidadeDasPalavrasTopDez()
        {
            try
            {
                return Ok(_palavraService.ObterQuantidadeDasPalavrasTopDez());
            }
            catch (System.Exception)
            {

                return BadRequest();
            }

        }

        [Route("ObterQuantidadePalavrasTopico")]
        [HttpGet]
        public ActionResult<IEnumerable<TopicoQuantidadePalavraResponse>> ObterQuantidadePalavrasTopico()
        {
            try
            {
                return Ok(_palavraService.ObterQuantidadePalavrasTopico());
            }
            catch (System.Exception)
            {

                return BadRequest();
            }
        }

    }
}
