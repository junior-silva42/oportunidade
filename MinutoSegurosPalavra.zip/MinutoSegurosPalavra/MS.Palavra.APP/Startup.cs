﻿using ElmahCore.Mvc;
using ElmahCore.Sql;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using MS.Palavra.Domain.Entities.Base;
using MS.Palavra.Domain.Interfaces.Repository;
using MS.Palavra.Domain.Interfaces.Service;
using MS.Palavra.Domain.Interfaces.UnitOfWork;
using MS.Palavra.Infra.Context;
using MS.Palavra.Infra.Repositories.Base;
using MS.Palavra.Infra.UnitOfWork;
using MS.Palavra.Service.Services;
using Swashbuckle.AspNetCore.Swagger;
using System.Linq;

namespace MS.Palavra.APP
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            #region Padrao
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);
            #endregion
            #region Repositorio
            services.AddDbContext<PalavraContext>(options => options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
            services.AddScoped<IRepository<BaseEntity>, BaseRepository<BaseEntity>>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            #endregion
            #region Service
            services.AddScoped<IPalavraService, PalavraService>();
            #endregion
            #region Swagger
            services.AddSwaggerGen(c =>
                      {
                          c.SwaggerDoc("v1", new Info { Title = "Teste Minuto", Version = "v1" });
                          c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
                      });
            #endregion
            #region Elmah
            services.AddElmah<SqlErrorLog>(options =>
            {
                options.Path = @"errors";
                options.LogPath = "~/logs";
                options.ConnectionString = Configuration.GetConnectionString("DefaultConnection"); // DB estrutura rodar o arquivo do link: https://bitbucket.org/project-elmah/main/downloads/ELMAH-1.2-db-SQLServer.sql
            });
            #endregion
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            #region Padrao
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseHsts();
            }
            app.UseHttpsRedirection();
            app.UseMvc();
            #endregion
            #region Swagger
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "V1 Docs");
            });
            #endregion
            #region Elmah
            app.UseElmah();
            #endregion
        }
    }
}
